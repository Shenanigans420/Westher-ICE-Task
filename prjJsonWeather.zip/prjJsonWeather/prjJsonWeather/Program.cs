﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Net.Http;

namespace prjJsonWeather {
    class Program {
        static void Main(string[] args) {
            getWeather();
        }
        public static void getWeather() {
            
            var url = "https://api.openweathermap.org/data/2.5/weather?q=Gauteng&appid=9565a5e74fc933e11f56c97bb1ee65fb";

            var httpRequest = (HttpWebRequest)WebRequest.Create(url);

            httpRequest.Accept = "application/json";


            var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream())) {
                Console.WriteLine("Request Response: " + httpResponse.StatusCode);

                var result = streamReader.ReadToEnd();
                var resultsParsed = JsonConvert.SerializeObject(result);
                Console.WriteLine(resultsParsed);
            }
        }
    }
}
